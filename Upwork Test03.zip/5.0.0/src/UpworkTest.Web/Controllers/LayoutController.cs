namespace UpworkTest.Web.Controllers
{
    public class LayoutController : UpworkTestControllerBase
    {

    }
}