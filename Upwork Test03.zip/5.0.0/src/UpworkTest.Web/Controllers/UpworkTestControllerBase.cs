using Abp.AspNetCore.Mvc.Controllers;

namespace UpworkTest.Web.Controllers
{
    public abstract class UpworkTestControllerBase: AbpController
    {
        protected UpworkTestControllerBase()
        {
            LocalizationSourceName = UpworkTestConsts.LocalizationSourceName;
        }
    }
}