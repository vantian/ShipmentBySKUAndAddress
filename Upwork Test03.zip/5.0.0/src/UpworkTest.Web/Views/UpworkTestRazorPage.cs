﻿using Abp.AspNetCore.Mvc.Views;

namespace UpworkTest.Web.Views
{
    public abstract class UpworkTestRazorPage<TModel> : AbpRazorPage<TModel>
    {
        protected UpworkTestRazorPage()
        {
            LocalizationSourceName = UpworkTestConsts.LocalizationSourceName;
        }
    }
}
