﻿using Abp.AspNetCore;
using Abp.AspNetCore.Configuration;
using Abp.Modules;
using Abp.Reflection.Extensions;
using UpworkTest.Configuration;
using UpworkTest.EntityFrameworkCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.ApplicationParts;
using Microsoft.Extensions.Configuration;

namespace UpworkTest.Web.Startup
{
    [DependsOn(
        typeof(UpworkTestApplicationModule), 
        typeof(UpworkTestEntityFrameworkCoreModule), 
        typeof(AbpAspNetCoreModule))]
    public class UpworkTestWebModule : AbpModule
    {
        private readonly IConfigurationRoot _appConfiguration;

        public UpworkTestWebModule(IHostingEnvironment env)
        {
            _appConfiguration = AppConfigurations.Get(env.ContentRootPath, env.EnvironmentName);
        }

        public override void PreInitialize()
        {
            Configuration.DefaultNameOrConnectionString = _appConfiguration.GetConnectionString(UpworkTestConsts.ConnectionStringName);

            Configuration.Navigation.Providers.Add<UpworkTestNavigationProvider>();

            Configuration.Modules.AbpAspNetCore()
                .CreateControllersForAppServices(
                    typeof(UpworkTestApplicationModule).GetAssembly()
                );
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(UpworkTestWebModule).GetAssembly());
        }

        public override void PostInitialize()
        {
            IocManager.Resolve<ApplicationPartManager>()
                .AddApplicationPartsIfNotAddedBefore(typeof(UpworkTestWebModule).Assembly);
        }
    }
}