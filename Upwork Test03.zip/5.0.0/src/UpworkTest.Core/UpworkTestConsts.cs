﻿namespace UpworkTest
{
    public class UpworkTestConsts
    {
        public const string LocalizationSourceName = "UpworkTest";

        public const string ConnectionStringName = "Default";
    }
}