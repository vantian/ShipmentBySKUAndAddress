﻿using Abp.Modules;
using Abp.Reflection.Extensions;
using UpworkTest.Localization;

namespace UpworkTest
{
    public class UpworkTestCoreModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.Auditing.IsEnabledForAnonymousUsers = true;

            UpworkTestLocalizationConfigurer.Configure(Configuration.Localization);
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(UpworkTestCoreModule).GetAssembly());
        }
    }
}