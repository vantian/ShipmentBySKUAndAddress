﻿using Abp.Application.Services;

namespace UpworkTest
{
    /// <summary>
    /// Derive your application services from this class.
    /// </summary>
    public abstract class UpworkTestAppServiceBase : ApplicationService
    {
        protected UpworkTestAppServiceBase()
        {
            LocalizationSourceName = UpworkTestConsts.LocalizationSourceName;
        }
    }
}