﻿using Abp.AutoMapper;
using Abp.Modules;
using Abp.Reflection.Extensions;

namespace UpworkTest
{
    [DependsOn(
        typeof(UpworkTestCoreModule), 
        typeof(AbpAutoMapperModule))]
    public class UpworkTestApplicationModule : AbpModule
    {
        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(UpworkTestApplicationModule).GetAssembly());
        }
    }
}