﻿using Abp.EntityFrameworkCore;
using Abp.Modules;
using Abp.Reflection.Extensions;

namespace UpworkTest.EntityFrameworkCore
{
    [DependsOn(
        typeof(UpworkTestCoreModule), 
        typeof(AbpEntityFrameworkCoreModule))]
    public class UpworkTestEntityFrameworkCoreModule : AbpModule
    {
        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(UpworkTestEntityFrameworkCoreModule).GetAssembly());
        }
    }
}