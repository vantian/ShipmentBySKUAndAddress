﻿using Abp.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace UpworkTest.EntityFrameworkCore
{
    public class UpworkTestDbContext : AbpDbContext
    {
        //Add DbSet properties for your entities...

        public UpworkTestDbContext(DbContextOptions<UpworkTestDbContext> options) 
            : base(options)
        {

        }
    }
}
