using Abp.AspNetCore.TestBase;
using Abp.Modules;
using Abp.Reflection.Extensions;
using UpworkTest.Web.Startup;
namespace UpworkTest.Web.Tests
{
    [DependsOn(
        typeof(UpworkTestWebModule),
        typeof(AbpAspNetCoreTestBaseModule)
        )]
    public class UpworkTestWebTestModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.UnitOfWork.IsTransactional = false; //EF Core InMemory DB does not support transactions.
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(UpworkTestWebTestModule).GetAssembly());
        }
    }
}