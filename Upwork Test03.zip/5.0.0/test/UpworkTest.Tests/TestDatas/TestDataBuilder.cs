using UpworkTest.EntityFrameworkCore;

namespace UpworkTest.Tests.TestDatas
{
    public class TestDataBuilder
    {
        private readonly UpworkTestDbContext _context;

        public TestDataBuilder(UpworkTestDbContext context)
        {
            _context = context;
        }

        public void Build()
        {
            //create test data here...
        }
    }
}