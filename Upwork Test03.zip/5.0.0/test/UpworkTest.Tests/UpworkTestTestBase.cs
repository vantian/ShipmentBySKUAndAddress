﻿using System;
using System.Threading.Tasks;
using Abp.TestBase;
using UpworkTest.EntityFrameworkCore;
using UpworkTest.Tests.TestDatas;

namespace UpworkTest.Tests
{
    public class UpworkTestTestBase : AbpIntegratedTestBase<UpworkTestTestModule>
    {
        public UpworkTestTestBase()
        {
            UsingDbContext(context => new TestDataBuilder(context).Build());
        }

        protected virtual void UsingDbContext(Action<UpworkTestDbContext> action)
        {
            using (var context = LocalIocManager.Resolve<UpworkTestDbContext>())
            {
                action(context);
                context.SaveChanges();
            }
        }

        protected virtual T UsingDbContext<T>(Func<UpworkTestDbContext, T> func)
        {
            T result;

            using (var context = LocalIocManager.Resolve<UpworkTestDbContext>())
            {
                result = func(context);
                context.SaveChanges();
            }

            return result;
        }

        protected virtual async Task UsingDbContextAsync(Func<UpworkTestDbContext, Task> action)
        {
            using (var context = LocalIocManager.Resolve<UpworkTestDbContext>())
            {
                await action(context);
                await context.SaveChangesAsync(true);
            }
        }

        protected virtual async Task<T> UsingDbContextAsync<T>(Func<UpworkTestDbContext, Task<T>> func)
        {
            T result;

            using (var context = LocalIocManager.Resolve<UpworkTestDbContext>())
            {
                result = await func(context);
                context.SaveChanges();
            }

            return result;
        }
    }
}
