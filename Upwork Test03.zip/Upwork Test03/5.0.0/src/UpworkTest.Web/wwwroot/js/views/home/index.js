﻿(function ($) {
    $(function () {
        var _orderService = abp.services.app.order;
        var addr1 = { firstName: "Clark", lastName: "Kent", address: "250 Mayfair St.", city: "Warwick", state: "RI", zipPostalCode: "02886", country: "USA" };
        var addr2 = { firstName: "Bruce", lastName: "Wayne", address: "9787 Walnut Ave", city: "Lansdale", state: "RI", zipPostalCode: "02886", country: "USA" };
        var addr3 = { firstName: "Diana", lastName: "Prince", address: "47 Orange Court", city: "Konoha", state: "PA", zipPostalCode: "19446", country: "USA" };
        var addr4 = { firstName: "Barry", lastName: "Allen", address: "7947 Brookside Ave", city: "Grand Line", state: "PA", zipPostalCode: "19446", country: "USA" };
        var addr5 = { firstName: "Ray", lastName: "Fisher", address: "685 Race Lane", city: "Riverdale", state: "PA", zipPostalCode: "19446", country: "USA" };
        var addreses = [addr1, addr2, addr3, addr4, addr5];
        var sku = ["SKU001", "SKU002", "SKU003"];

        $(document).ready(function () {
            //generate random requests
            var totalOrders = getRandomArbitrary(1, 5);
            var orderRequest = [];

            for (var i = 0; i < totalOrders; i++) {
                var order = {};
                var products = [];
                var totalProducts = getRandomArbitrary(1, 2);
                var randomAddressId = getRandomArbitrary(0, 2);

                for (var p = 0; p < totalProducts; p++) {
                    var randomSkuId = getRandomArbitrary(0, 2);
                    
                    var product = {};
                    product["sku"] = sku[randomSkuId];
                    product["qty"] = getRandomArbitrary(1, 10);
                    products.push(product);
                }
                order["orderId"] = "Order #0" + (i + 1);
                order["address"] = addreses[randomAddressId];
                order["products"] = products;
                orderRequest.push(order);
            }

            //document.getElementById('requestJson').appendChild(document.createTextNode());
            $('#requestJson').text(JSON.stringify(orderRequest, null, 4));

            _orderService.processOrders({ "Orders": orderRequest })
                .done(function (e) {
                    //abp.notify.info('Data Saved Successfully');
                    $('#responseJson').text(JSON.stringify(e, null, 4));
                });
        });

        function getRandomArbitrary(min, max) {
            return Math.floor(Math.random() * (max - min + 1)) + min;
        }
    });

})(jQuery);