using Microsoft.AspNetCore.Mvc;

namespace UpworkTest.Web.Controllers
{
    public class HomeController : UpworkTestControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}