﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using UpworkTest.Orders.Dto;

namespace UpworkTest.Orders
{
    public interface IOrderAppService : IApplicationService
    {
        IList<ShipmentDto> ProcessOrders(OrdersInputDto input);
    }
}
