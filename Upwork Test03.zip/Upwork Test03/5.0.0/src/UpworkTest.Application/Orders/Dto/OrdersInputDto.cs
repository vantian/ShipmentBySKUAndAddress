﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UpworkTest.Orders.Dto
{
    public class OrdersInputDto
    {
        public IList<OrderDto> Orders { get; set; }

        public OrdersInputDto()
        {
            this.Orders = new List<OrderDto>();
        }
    }
}
