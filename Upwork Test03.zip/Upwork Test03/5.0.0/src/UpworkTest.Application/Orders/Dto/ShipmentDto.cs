﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UpworkTest.Orders.Dto
{
    public class ShipmentDto
    {
        public string ShipmentId { get; set; }
        public IList<OrderDto> Orders { get; set; }

        public ShipmentDto()
        {
            this.Orders = new List<OrderDto>();
        }
        public ShipmentDto(int shipmentId)
        {
            this.ShipmentId = "Shipment #" + shipmentId;
            this.Orders = new List<OrderDto>();
        }
    }
}
