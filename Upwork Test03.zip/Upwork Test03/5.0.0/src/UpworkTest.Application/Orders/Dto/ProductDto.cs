﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UpworkTest.Orders.Dto
{
    public class ProductDto
    {
        public string Sku { get; set; }
        public int Qty { get; set; }
    }
}
