﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UpworkTest.Orders.Dto
{
    public class OrderDto
    {
        public string OrderId { get; set; }
        public AddressDto Address { get; set; }
        public IList<ProductDto> Products { get; set; }

        public OrderDto()
        {
            this.Products = new List<ProductDto>();
        }
    }
}
