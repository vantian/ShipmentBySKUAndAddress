﻿using Abp.Application.Services.Dto;
using Abp.Authorization;
using Abp.Domain.Repositories;
using Abp.UI;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UpworkTest.Orders.Dto;

namespace UpworkTest.Orders
{
    public class OrderAppService : UpworkTestAppServiceBase, IOrderAppService
    {
        public OrderAppService()
        {
        }

        public IList<ShipmentDto> ProcessOrders(OrdersInputDto input)
        {
            var response = new List<ShipmentDto>();
            try
            {
                var groupedByZipCodes = input.Orders.GroupBy(e => e.Address.ZipPostalCode);

                var ordersGroupedBySku = groupedByZipCodes
                    .Select(g => new
                    {
                        Key = g.Key,
                        Count = g.Count(),
                        productCategoryGroups = g.SelectMany(p => p.Products, (p, c) => new { p, c })
                        .GroupBy(x => x.c.Sku, x => x.p)
                    });

                int loop = 1;
                foreach (var group in ordersGroupedBySku)
                {
                    foreach (var SKU in group.productCategoryGroups)
                    {
                        var shipment = new ShipmentDto(loop);
                        foreach (var order in SKU)
                        {
                            shipment.Orders.Add(new OrderDto()
                            {
                                Address = order.Address,
                                OrderId = order.OrderId,
                                Products = order.Products.Where(e => e.Sku == SKU.Key).ToList()
                            });
                        }
                        response.Add(shipment);
                        loop++;
                    }
                }
            }
            catch (Exception ex)
            {
                //var x = ex;
            }

            return response;
        }
    }
}
